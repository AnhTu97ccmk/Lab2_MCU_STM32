/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License". You may obtain a copy of the License at:
  * opensource.org/licenses/BSD-3-Clause
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TIMER_CYCLE 10       // TIM2 interrupt period = 10 ms

/* ----------------------------------------------------------
 * CỰC TÍNH CỦA LED MATRIX (theo schematic Proteus)
 *
 *  3.3V --[100R]--+-- COL (anode của LED)
 *                 |
 *               ULN2803 (mạch ĐẢO): ENM = 1 -> kéo COL xuống GND
 *
 *  ENM = 0 -> ULN tắt -> COL được cấp 3.3V  -> cột BẬT
 *  ENM = 1 -> ULN dẫn -> COL bị nối GND     -> cột TẮT
 *  ROW là catode nối thẳng MCU: ROW = 0 -> LED sáng
 *
 *  Nếu matrix của bạn vẫn không đúng, thử đảo 4 define này.
 * ---------------------------------------------------------- */
#define COL_ON   GPIO_PIN_RESET
#define COL_OFF  GPIO_PIN_SET
#define ROW_ON   GPIO_PIN_RESET
#define ROW_OFF  GPIO_PIN_SET
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */

/* ==========================================================
 * SOFTWARE TIMERS
 * ========================================================== */

// Timer 1: 1000 ms -> digital clock + DOT
volatile int timer1_counter = 0;
volatile int timer1_flag = 0;

void setTimer1(int duration)
{
    timer1_counter = duration / TIMER_CYCLE;
    timer1_flag = 0;
}

// Timer 2: 250 ms -> 4 seven-segment scan
volatile int timer2_counter = 0;
volatile int timer2_flag = 0;

void setTimer2(int duration)
{
    timer2_counter = duration / TIMER_CYCLE;
    timer2_flag = 0;
}

// Timer 3: 10 ms -> LED Matrix scan
volatile int timer3_counter = 0;
volatile int timer3_flag = 0;

void setTimer3(int duration)
{
    timer3_counter = duration / TIMER_CYCLE;
    timer3_flag = 0;
}

// Timer 4: 500 ms -> LED Matrix animation
volatile int timer4_counter = 0;
volatile int timer4_flag = 0;

void setTimer4(int duration)
{
    timer4_counter = duration / TIMER_CYCLE;
    timer4_flag = 0;
}

/* ==========================================================
 * 7-SEGMENT DISPLAY
 * ========================================================== */

const uint8_t segCode[10] =
{
    0x40,  // 0
    0x79,  // 1
    0x24,  // 2
    0x30,  // 3
    0x19,  // 4
    0x12,  // 5
    0x02,  // 6
    0x78,  // 7
    0x00,  // 8
    0x10   // 9
};

void display7SEG(int num)
{
    if (num >= 0 && num <= 9)
    {
        uint8_t code = segCode[num];

        for (int i = 0; i < 7; i++)
        {
            if ((code >> i) & 0x01)
            {
                HAL_GPIO_WritePin(GPIOB,
                                  (GPIO_PIN_0 << i),
                                  GPIO_PIN_SET);
            }
            else
            {
                HAL_GPIO_WritePin(GPIOB,
                                  (GPIO_PIN_0 << i),
                                  GPIO_PIN_RESET);
            }
        }
    }
}

/* ==========================================================
 * DIGITAL CLOCK + 7-SEGMENT SCAN
 * ========================================================== */

const int MAX_LED = 4;
volatile int index_led = 0;
int led_buffer[4] = {0, 0, 0, 0};

void updateClockBuffer(int h, int m)
{
    led_buffer[0] = h / 10;
    led_buffer[1] = h % 10;
    led_buffer[2] = m / 10;
    led_buffer[3] = m % 10;
}

void update7SEG(int index)
{
    // Tắt toàn bộ 4 LED trước để chống bóng ma
    HAL_GPIO_WritePin(GPIOA,
                      GPIO_PIN_6 | GPIO_PIN_7 |
                      GPIO_PIN_8 | GPIO_PIN_9,
                      GPIO_PIN_SET);

    switch (index)
    {
        case 0:
            display7SEG(led_buffer[0]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET);
            break;

        case 1:
            display7SEG(led_buffer[1]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
            break;

        case 2:
            display7SEG(led_buffer[2]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
            break;

        case 3:
            display7SEG(led_buffer[3]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET);
            break;

        default:
            break;
    }
}

/* ==========================================================
 * EXERCISE 9 - LED MATRIX 8x8
 * ========================================================== */

const int MAX_LED_MATRIX = 8;
int index_led_matrix = 0;

// Mỗi phần tử là dữ liệu của một CỘT (matrix_buffer[0] = cột trái nhất).
// Bit i = ROW i (bit 0 = ROW0 ở trên cùng).  Bit = 1 -> LED sáng.
//
// Chữ A (6 cột rộng, 2 cột trống 2 bên):
//   r0: . . . X X . . .
//   r1: . . X . . X . .
//   r2: . X . . . . X .
//   r3: . X . . . . X .
//   r4: . X X X X X X .
//   r5: . X . . . . X .
//   r6: . X . . . . X .
//   r7: . X . . . . X .
uint8_t matrix_buffer[8] =
{
    0x00,
    0xFC,
    0x12,
    0x11,
    0x11,
    0x12,
    0xFC,
    0x00
};

// ENM0 -> PA2
// ENM1 -> PA3
// ENM2 -> PA10
// ENM3 -> PA11
// ENM4 -> PA12
// ENM5 -> PA13
// ENM6 -> PA14
// ENM7 -> PA15
uint16_t matrix_enable_pins[8] =
{
    GPIO_PIN_2,
    GPIO_PIN_3,
    GPIO_PIN_10,
    GPIO_PIN_11,
    GPIO_PIN_12,
    GPIO_PIN_13,
    GPIO_PIN_14,
    GPIO_PIN_15
};

void updateMatrixRows(uint8_t data)
{
    for (int i = 0; i < 8; i++)
    {
        uint16_t pin = (uint16_t)(GPIO_PIN_8 << i);   // ROW i -> PB(8+i)

        if ((data & (1 << i)) != 0)
        {
            HAL_GPIO_WritePin(GPIOB, pin, ROW_ON);    // ROW = 0 -> LED sáng
        }
        else
        {
            HAL_GPIO_WritePin(GPIOB, pin, ROW_OFF);   // ROW = 1 -> LED tắt
        }
    }
}

void updateLEDMatrix(int index)
{
    // 1. Tắt tất cả các cột trước (chống bóng ma)
    for (int i = 0; i < 8; i++)
    {
        HAL_GPIO_WritePin(GPIOA, matrix_enable_pins[i], COL_OFF);
    }

    if (index < 0 || index >= MAX_LED_MATRIX)
        return;

    // 2. Xuất dữ liệu của cột hiện tại ra các ROW
    updateMatrixRows(matrix_buffer[index]);

    // 3. Bật đúng một cột
    HAL_GPIO_WritePin(GPIOA, matrix_enable_pins[index], COL_ON);
}

/* ==========================================================
 * EXERCISE 10 - LED MATRIX ANIMATION
 * ========================================================== */

// Dịch vòng sang trái: cột ra khỏi bên trái sẽ xuất hiện lại bên phải
void shiftMatrixLeft(void)
{
    uint8_t first = matrix_buffer[0];

    for (int i = 0; i < 7; i++)
    {
        matrix_buffer[i] = matrix_buffer[i + 1];
    }

    matrix_buffer[7] = first;
}

/* ==========================================================
 * SOFTWARE TIMER RUNNER
 * ========================================================== */

void timer_run(void)
{
    // Timer 1 - Clock + DOT
    if (timer1_counter > 0)
    {
        timer1_counter--;

        if (timer1_counter == 0)
            timer1_flag = 1;
    }

    // Timer 2 - 7SEG scan
    if (timer2_counter > 0)
    {
        timer2_counter--;

        if (timer2_counter == 0)
            timer2_flag = 1;
    }

    // Timer 3 - Matrix scan
    if (timer3_counter > 0)
    {
        timer3_counter--;

        if (timer3_counter == 0)
            timer3_flag = 1;
    }

    // Timer 4 - Matrix animation
    if (timer4_counter > 0)
    {
        timer4_counter--;

        if (timer4_counter == 0)
            timer4_flag = 1;
    }
}

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_TIM2_Init(void);
static void MX_GPIO_Init(void);

/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* USER CODE BEGIN 1 */
    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    HAL_Init();

    /* USER CODE BEGIN Init */
    /* USER CODE END Init */

    SystemClock_Config();

    /* USER CODE BEGIN SysInit */
    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_TIM2_Init();
    MX_GPIO_Init();

    /* USER CODE BEGIN 2 */

    // Tắt 4 LED 7-segment
    HAL_GPIO_WritePin(GPIOA,
                      GPIO_PIN_6 | GPIO_PIN_7 |
                      GPIO_PIN_8 | GPIO_PIN_9,
                      GPIO_PIN_SET);

    // Tắt tất cả cột của LED Matrix (ENM = 1 -> cột bị kéo xuống GND)
    HAL_GPIO_WritePin(GPIOA,
                      GPIO_PIN_2 | GPIO_PIN_3 |
                      GPIO_PIN_10 | GPIO_PIN_11 |
                      GPIO_PIN_12 | GPIO_PIN_13 |
                      GPIO_PIN_14 | GPIO_PIN_15,
                      COL_OFF);

    // Tắt toàn bộ ROW của Matrix (ROW = 1 -> LED tắt)
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_8 | GPIO_PIN_9 |
                      GPIO_PIN_10 | GPIO_PIN_11 |
                      GPIO_PIN_12 | GPIO_PIN_13 |
                      GPIO_PIN_14 | GPIO_PIN_15,
                      ROW_OFF);

    HAL_TIM_Base_Start_IT(&htim2);

    /* USER CODE END 2 */

    int hour = 10, minute = 36, second = 50;

    updateClockBuffer(hour, minute);

    // Ex7 - clock + DOT
    setTimer1(1000);

    // Ex8 - 4 LED 7-segment scan
    setTimer2(250);

    // Ex9 - LED Matrix scan
    setTimer3(10);

    // Ex10 - animation every 500 ms
    setTimer4(500);

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* ======================================================
         * EXERCISE 7 - DIGITAL CLOCK + DOT
         * ====================================================== */
        if (timer1_flag == 1)
        {
            setTimer1(1000);

            // DOT đổi trạng thái mỗi 1 giây
            HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_4);

            second++;

            if (second >= 60)
            {
                second = 0;
                minute++;

                if (minute >= 60)
                {
                    minute = 0;
                    hour++;

                    if (hour >= 24)
                    {
                        hour = 0;
                    }
                }
            }

            updateClockBuffer(hour, minute);
        }

        /* ======================================================
         * EXERCISE 8 - 4 LED 7-SEGMENT SCAN
         * ====================================================== */
        if (timer2_flag == 1)
        {
            setTimer2(250);

            update7SEG(index_led);

            index_led++;

            if (index_led >= MAX_LED)
            {
                index_led = 0;
            }
        }

        /* ======================================================
         * EXERCISE 9 - LED MATRIX SCAN
         * ====================================================== */
        if (timer3_flag == 1)
        {
            setTimer3(10);

            updateLEDMatrix(index_led_matrix);

            index_led_matrix++;

            if (index_led_matrix >= MAX_LED_MATRIX)
            {
                index_led_matrix = 0;
            }
        }

        /* ======================================================
         * EXERCISE 10 - LED MATRIX ANIMATION
         * ====================================================== */
        if (timer4_flag == 1)
        {
            setTimer4(500);

            shiftMatrixLeft();
        }
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK |
                                  RCC_CLOCKTYPE_SYSCLK |
                                  RCC_CLOCKTYPE_PCLK1 |
                                  RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};

    htim2.Instance = TIM2;
    htim2.Init.Prescaler = 7999;
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = 9;
    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

    if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
    {
        Error_Handler();
    }

    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;

    if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
    {
        Error_Handler();
    }

    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;

    if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    /* GPIO Ports Clock Enable */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* ======================================================
     * GPIOA initial levels
     * ====================================================== */

    // PA2, PA3, PA10-PA15: ENM -> COL_OFF (SET) = cột Matrix TẮT
    HAL_GPIO_WritePin(GPIOA,
                      GPIO_PIN_2 | GPIO_PIN_3 |
                      GPIO_PIN_10 | GPIO_PIN_11 |
                      GPIO_PIN_12 | GPIO_PIN_13 |
                      GPIO_PIN_14 | GPIO_PIN_15,
                      COL_OFF);

    // PA4: DOT
    // PA5: old LED
    HAL_GPIO_WritePin(GPIOA,
                      GPIO_PIN_4 | GPIO_PIN_5,
                      GPIO_PIN_RESET);

    // PA6-PA9: 7SEG enable, HIGH means OFF
    HAL_GPIO_WritePin(GPIOA,
                      GPIO_PIN_6 | GPIO_PIN_7 |
                      GPIO_PIN_8 | GPIO_PIN_9,
                      GPIO_PIN_SET);

    /* ======================================================
     * GPIOB initial levels
     * PB0-PB6 = 7SEG segments
     * PB8-PB15 = Matrix rows (ROW_OFF = SET -> LED tắt)
     * ====================================================== */

    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_0 | GPIO_PIN_1 |
                      GPIO_PIN_2 | GPIO_PIN_3 |
                      GPIO_PIN_4 | GPIO_PIN_5 |
                      GPIO_PIN_6,
                      GPIO_PIN_RESET);

    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_8 | GPIO_PIN_9 |
                      GPIO_PIN_10 | GPIO_PIN_11 |
                      GPIO_PIN_12 | GPIO_PIN_13 |
                      GPIO_PIN_14 | GPIO_PIN_15,
                      ROW_OFF);

    /* ======================================================
     * GPIOA: PA2, PA3, PA4, PA5, PA6-PA9, PA10-PA15
     * ====================================================== */

    GPIO_InitStruct.Pin = GPIO_PIN_2 |
                          GPIO_PIN_3 |
                          GPIO_PIN_4 |
                          GPIO_PIN_5 |
                          GPIO_PIN_6 |
                          GPIO_PIN_7 |
                          GPIO_PIN_8 |
                          GPIO_PIN_9 |
                          GPIO_PIN_10 |
                          GPIO_PIN_11 |
                          GPIO_PIN_12 |
                          GPIO_PIN_13 |
                          GPIO_PIN_14 |
                          GPIO_PIN_15;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ======================================================
     * GPIOB: PB0-PB6
     * ====================================================== */

    GPIO_InitStruct.Pin = GPIO_PIN_0 |
                          GPIO_PIN_1 |
                          GPIO_PIN_2 |
                          GPIO_PIN_3 |
                          GPIO_PIN_4 |
                          GPIO_PIN_5 |
                          GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* ======================================================
     * GPIOB: PB8-PB15 for LED Matrix
     * ====================================================== */

    GPIO_InitStruct.Pin = GPIO_PIN_8 |
                          GPIO_PIN_9 |
                          GPIO_PIN_10 |
                          GPIO_PIN_11 |
                          GPIO_PIN_12 |
                          GPIO_PIN_13 |
                          GPIO_PIN_14 |
                          GPIO_PIN_15;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */

/**
  * @brief Timer interrupt callback.
  * TIM2 interrupt occurs every 10 ms.
  * Only software timers are processed here.
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM2)
    {
        timer_run();
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    __disable_irq();

    while (1)
    {
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
    /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
    /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
